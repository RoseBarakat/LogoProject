
<?php
$connection = new PDO( 'mysql:host=localhost;dbname=webpro', 'root', '' );
?>
