<meta charset="utf-8">
<html lang="en">
<head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <meta charset="UTF-8">
    <title> Rota Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        body{
            background-color: #E4ECFA;
        }
        .chart-wrapper{
            width: 500px;
            height:500px;
        }
    </style>
</head>
<body>
<h3>Choose the UserName to designer to know the percentage of his logos to all ones:</h3>
<pre>                                      <form  method="post">
    <select name="Choice">
        <option value="000001">000001</option>
        <option value="000002">000002</option>
        <option value="000003">000003</option>
    </select>
    <input type="submit" value="Generate the Chart" name="bu">
    </form></pre>
<div class="chart-wrapper">
    <canvas id="myChart" class="chart-canvas"></canvas>
</div>
<script src=" https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
<script src="J.js"></script>

</body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webpro";

if(isset($_POST['bu'])) {
    $selectOption = $_POST['Choice'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql="select * From logo";
    $res=$conn->query($sql);
    $counter2=0;
    if ($res && $res->num_rows > 0) {
        while ($row = $res->fetch_assoc()) {
            $counter2 ++;
        }
    } else {
        echo "0 results";
    }

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql1 = "select UserNameDesigner From logo where UserNameDesigner=$selectOption";
    $res1 = $conn->query($sql1);
    $counter =0;
    if ($res1 && $res1->num_rows > 0) {
        while ($row = $res1->fetch_assoc()) {
            $counter ++;
        }
    } else {
        echo "0 results";
    }

    $conn->close();
}

?>
</html>